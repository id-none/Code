#pragma once
#ifndef __DFS2_H__
#define __DFS2_H__
#include "DFS.h"
#pragma warning(disable:4996)
#include "DFS.h"
#include "Assistance.h"	
template <class ElemType, class WeightType>
void DFS2(const AdjListDirNetwork<ElemType, WeightType>& g, int v ,int &vn ,int &en)
{
	ElemType * p;
	g.SetTag(v, VISITED);//���ö���a���ʱ�־
	++vn;//���ʵĵ�++
	for (int w = g.FirstAdjVex(v); w != -1; w = g.NextAdjVex(v, w))
	{
		++en;//����++
		if (g.GetTag(w) == UNVISITED)
			DFS2(g, w, vn, en);	
	}
}
template <class ElemType, class WeightType>
int IsTree(const AdjListDirNetwork< ElemType, WeightType>& g)
{
	int vn = 0, en = 0, v;
	for (v = 0; v < g.GetVexNum(); v++)
		g.SetTag(v, UNVISITED);// ��ÿ����������δ���ʱ�־;
	for (v = 0; v < g.GetVexNum(); v++)
        if (g.GetTag(v) == UNVISITED)
			DFS2(g, v, vn, en);
	if (vn == g.GetVexNum() && (g.GetVexNum() - 1) == en / 2)
		return 1;
	else
		return 0;
}
#endif